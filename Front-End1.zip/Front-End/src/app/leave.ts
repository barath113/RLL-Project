export class Leave {
    id!: number;
    from_date!: Date;
    to_date!: Date;
    leave_type!: string; 
    reason!: string;
    status!: string; 
}
